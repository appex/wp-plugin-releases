<?php
// exit if accessed directly
if (!defined('ABSPATH')) exit;

// check if class already exists
if (!class_exists('APPEX_IMGIX_acf_field_crop_method')) :

class APPEX_IMGIX_acf_field_crop_method extends acf_field {

	/*
	*  __construct
	*
	*  This function will setup the field type data
	*
	*  @type	function
	*  @date	5/03/2014
	*  @since	5.0.0
	*
	*  @param	n/a
	*  @return	n/a
	*/

	public $name;
	public $label;
	public $category;
	public $defaults;
	public $l10n;
	public $settings;

	function __construct($settings) {

		/*
		*  name (string) Single word, no spaces. Underscores allowed
		*/

		$this->name = 'crop_method';


		/*
		*  label (string) Multiple words, can include spaces, visible when selecting a field type
		*/

		$this->label = 'Imgix crop method';


		/*
		*  category (string) basic | content | choice | relational | jquery | layout | CUSTOM GROUP NAME
		*/

		$this->category = 'choice';


		/*
		*  defaults (array) Array of default settings which are merged into the field object. These are used later in settings
		*/

		$this->defaults = [
			'crop_method'	=> 'entropy',
		];


		/*
		*  l10n (array) Array of strings that are used in JavaScript. This allows JS strings to be translated in PHP and loaded via:
		*  var message = acf._e('crop_method', 'error');
		*/

		$this->l10n = [
			'error'	=> 'Error! Please enter a higher value',
		];


		/*
		*  settings (array) Store plugin settings (url, path, version) as a reference for later use with assets
		*/

		$this->settings = $settings;


		// do not delete!
    	parent::__construct();

	}



	/*
	*  get_crop_methods_array()
	*
	*  List all available crop methods
	*
	*  @type	function
	*  @since	1.1.36
	*  @date	10/04/19
	*
	*  @return	array
	*/

	function get_crop_methods_array() {
		return [
			'faces' => 'Ansikter',
			'entropy' => 'Entropy',
			'focalpoint' => 'Fokalpunkt - manuelt definert',
			'centered' => 'Sentrert',
		];
	}



	/*
	*  render_field_settings()
	*
	*  Create extra settings for your field. These are visible when editing a field
	*
	*  @type	action
	*  @since	3.6
	*  @date	23/01/13
	*
	*  @param	$field (array) the $field being edited
	*  @return	n/a
	*/

	function render_field_settings($field) {

		/*
		*  acf_render_field_setting
		*
		*  This function will create a setting for your field. Simply pass the $field parameter and an array of field settings.
		*  The array of settings does not require a `value` or `prefix`; These settings are found from the $field array.
		*
		*  More than one setting can be added by copy/paste the above code.
		*  Please note that you must also have a matching $defaults value for the field name (crop_method)
		*/


		acf_render_field_setting($field, [
			'label' => 'Default setting for imgix crop method',
			'instructions' => 'Override the default value for this field',
			'type' => 'select',
			'name' => 'crop_method_default_value',
			'choices' => $this->get_crop_methods_array(),
			'default_value' => $this->defaults['crop_method'],
		]);

	}



	/*
	*  render_field()
	*
	*  Create the HTML interface for your field
	*
	*  @param	$field (array) the $field being rendered
	*
	*  @type	action
	*  @since	3.6
	*  @date	23/01/13
	*
	*  @param	$field (array) the $field being edited
	*  @return	n/a
	*/

	function render_field($field) {
		$prev_value_method = $field['value']['crop'];
		$prev_value_horizontal = $prev_value_vertical = 50;
		$crop_methods = $this->get_crop_methods_array();

		if (isset($field['value']) && $field['value']) {
			if (isset($field['value']['crop'])) {
				$prev_value_method = $field['value']['crop'];
			}

			if (isset($field['value']['fp-x'])) {
				$prev_value_horizontal = $field['value']['fp-x'] * 100;
			}

			if (isset($field['value']['fp-y'])) {
				$prev_value_vertical = $field['value']['fp-y'] * 100;
			}
		}

		echo '<select name="' . esc_attr($field['name']) . '-selector" class="appex_imgix_crop_method_select">';

		foreach ($crop_methods as $crop_key => $crop_method) {
			if ($prev_value_method == $crop_key || (!$prev_value_method && $field['crop_method_default_value'] == $crop_key)) {
				$selected = ' selected="selected" ';
			} else {
				$selected = null;
			}

			$crop_method_title = $crop_method;

			if ($field['crop_method_default_value'] == $crop_key) {
				$crop_method_title .= ' - (standard)';
			}

			echo '<option value="' . $crop_key . '" ' . $selected . '>' . $crop_method_title . '</option>';
		}

		echo '</select>';

		echo '<input type="hidden" value="' . implode(';', $field['value']) . '" name="' . esc_attr($field['name']) . '" class="appex_imgix_crop_method">';
		echo '<input type="hidden" value="' . $prev_value_horizontal . '" name="appex_imgix_crop_focal_horizontal"  class="appex_imgix_crop_focal_horizontal">';
		echo '<input type="hidden" value="' . $prev_value_vertical . '" name="appex_imgix_crop_focal_vertical" class="appex_imgix_crop_focal_vertical">';
	}



	/*
	*  load_value()
	*
	*  This filter is applied to the $value after it is loaded from the db
	*
	*  @type	filter
	*  @since	3.6
	*  @date	23/01/13
	*
	*  @param	$value (mixed) the value found in the database
	*  @param	$post_id (mixed) the $post_id from which the value was loaded
	*  @param	$field (array) the field array holding all the field options
	*  @return	$value
	*/


	function load_value($value, $post_id, $field) {
		$data = [
			'crop' => '',
		];

		if ($value != null && $value != '') {
			$values = explode(';', $value);

			if (isset($values[0]) && $values[0]) {
				$data['crop'] = $values[0];
			}

			if (isset($values[1]) && $values[1]) {
				$data['fp-x'] = $values[1] / 100;
			}

			if (isset($values[2]) && $values[2]) {
				$data['fp-y'] = $values[2] / 100;
			}
		}

		return $data;
	}

}


// initialize
new APPEX_IMGIX_acf_field_crop_method($this->settings);


// class_exists check
endif;
