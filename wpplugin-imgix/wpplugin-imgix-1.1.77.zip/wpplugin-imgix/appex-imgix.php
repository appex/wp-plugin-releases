<?php
/*
 * Plugin Name: Appex Imgix
 * Version: 1.1.77
 * Plugin URI: http://www.appex.no
 * Description: Serve images through Imgix
 * Author: Appex
 * Author URI: http://www.appex.no
 */

define('APPEX_IMGIX_CACHE_PATH', WP_CONTENT_DIR .'/uploads/appex-imgix/');

require 'plugin-update-checker/plugin-update-checker.php';
require 'imgix-php/src/autoload.php';
require 'acf-imgix-crop-method/acf-imgix-crop-method.php';

use Imgix\UrlBuilder;
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

// Updates are read from the public appex/wp-plugin-releases repo, so sites need no GitHub
// credentials. .github/workflows/release.yml publishes info.json and the plugin zip there on
// every version bump.
$pluginUpdateChecker = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/appex/wp-plugin-releases/main/wpplugin-imgix/info.json',
	__FILE__,
	'wpplugin-imgix'
);

// Create custom plugin settings menu
add_action('admin_menu', function() {
	$path = rtrim(plugin_dir_url(__FILE__)) .'/images/icon.svg';

	add_menu_page(
		'Appex Imgix',
		'Appex Imgix',
		'administrator',
		__FILE__,
		'appex_imgix_settings_page',
		$path
	);
});

// Register settings
add_action('admin_init', function() {
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-domain');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-caching');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-secure-urls');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-secure-urls-token');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-use-content-url-for-replacement');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-use-core-blocks');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-replace-core-functions');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-replace-post-content');
	register_setting('appex_imgix-default-setting-group', 'appex_imgix-max-width');
});

function appex_imgix_settings_page() {
?>
<div class="wrap">
	<h1>Appex Imgix alternativer</h1>

	<form method="post" action="options.php">

		<?php
		settings_fields('appex_imgix-default-setting-group');
		do_settings_sections('appex_imgix-default-setting-group');
		?>

		<table class="form-table">
			<tr valign="top">
				<th scope="row">
					Imgix domain URL
					<small>URL (without https://)</small>
				</th>

				<td>
					<input placeholder="subdomene.imgix.net" type="text" size="60" name="appex_imgix-domain" value="<?php echo esc_attr(get_option('appex_imgix-domain')); ?>" />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
					Activate caching?
					<small>Experimental feature</small>
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-caching" <?php if (get_option('appex_imgix-caching') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
					Enable Secure Urls?
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-secure-urls" <?php if (get_option('appex_imgix-secure-urls') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
					Enter secure url token
				</th>

				<td>
					<input placeholder="legginnimgixkeyher" type="text" size="60" name="appex_imgix-secure-urls-token" value="<?php echo esc_attr(get_option('appex_imgix-secure-urls-token')); ?>" />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
				Use content URL for replacement?
				<small> (Only for multi-tenancy setups)</small>
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-use-content-url-for-replacement" <?php if (get_option('appex_imgix-use-content-url-for-replacement') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
				Use Imgix with core WordPress blocks?
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-use-core-blocks" <?php if (get_option('appex_imgix-use-core-blocks') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
				Replace core WordPress functions?
				<br><small>Required for support with core/post-featured-image</small>
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-replace-core-functions" <?php if (get_option('appex_imgix-replace-core-functions') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
				Replace images in post content?
				<br><small>For sites using the classic editor only</small>
				</th>

				<td>
					<input type="checkbox" size="60" name="appex_imgix-replace-post-content" <?php if (get_option('appex_imgix-replace-post-content') == 'on') { echo ' checked'; } ?> />
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">
				Max image width
				</th>

				<td>
					<input placeholder="1500" type="number" size="10" name="appex_imgix-max-width" value="<?php echo esc_attr(get_option('appex_imgix-max-width')); ?>" />
				</td>
			</tr>

		</table>

		<?php submit_button(); ?>

	</form>
</div>

<hr>
<h2>Documentation:</h2>
<pre>
/**
 * get_aix_image()
 * This function returns an image tag via the Imgix Proxy
 *
 * @param int $attachment_id
 * @param array $size
 * @param boolean $crop
 * @param array $imgix_options
 * @param array $aix_options
 * @return string
 */
get_aix_image($attachment_id, $size, $crop = true, $imgix_options = [], $aix_options);
</pre>
<h4>Example</h4>
<pre>
<code>echo get_aix_image(get_post_thumbnail_id(), [960, 450], true, ['sat' => '-100']);</code>
Prints an <code>&lt;img&gt;</code> with a black/white version of the featured image for post, cropped to 960px width, 450px height
</pre>
<p>
<a href="https://sandbox.imgix.com/">Imgix sandbox</a>
</p>

<h3>Setting default values with filters</h3>
<pre>
<code>// Set default Appex Imgix options
function my_theme_name_default_imgix_options($imgix_options) {
	$imgix_options['auto'] = 'compress';
	return $imgix_options;
}
add_filter('aix_default_imgix_options', 'my_theme_name_default_imgix_options');</code>
</pre>

<br><h3>Usage with Gutenberg</h3>
<h4>Post featured image</h4>
<pre>
<code>function aix_register_post_thumbnail_size() {
	add_image_size('post-thumbnail', 300, 300);
}
add_action('after_setup_theme', 'aix_register_post_thumbnail_size');
</code>
</pre>

<?php
}

add_action('admin_enqueue_scripts', function() {
	$versionJs = filemtime(plugin_dir_path(__FILE__) .'dist/appex-imgix-admin-script.js');
	$versionCss = filemtime(plugin_dir_path(__FILE__) .'dist/appex-imgix-admin-style.css');
    wp_enqueue_style('appex_imgix_admin_style', plugin_dir_url(__FILE__) .'dist/appex-imgix-admin-style.css', [], $versionCss);
    wp_enqueue_script('appex_imgix_admin_script', plugin_dir_url(__FILE__) .'dist/appex-imgix-admin-script.js', [], $versionJs, false);
});

function appex_imgix_ensure_cache_folder_exists() {
	$exists = true;

	if (!file_exists(APPEX_IMGIX_CACHE_PATH)) {
		$exists = wp_mkdir_p(APPEX_IMGIX_CACHE_PATH);
	}

	if ($exists) {
		return APPEX_IMGIX_CACHE_PATH;
	}
}

function appex_imgix_cached_image_exists($name) {
	if (file_exists(APPEX_IMGIX_CACHE_PATH . $name)) {
		return content_url() .'/uploads/appex-imgix/'. $name;
	}

	return false;
}


function appex_imgix_set_imgix_options($imgix_options) {
	// Default Imgix parameters - fallback to this when no parameters are provided with filter og function
	$imgix_default_options = [
		'auto' => 'format,compress',
		'crop' => 'faces'
	];

	$imgix_default_options = apply_filters('aix_default_imgix_options', $imgix_default_options);
	$imgix_options = $imgix_options ? array_merge($imgix_default_options, $imgix_options) : $imgix_default_options;

	return $imgix_options;
}

function appex_imgix_set_aix_options($aix_options) {
	// Default parameters for this function - fallback to this when no parameters are provided with filter og function
	$aix_default_options = [
		'show_caption' => false,
		'caption_prefix' => false,
		'caption_suffix' => false,
		'return_data_src' => false,
		'insert_placeholder' => false,
		'img_class' => null,
		'return' => false,
		'output_title' => false,
	];

	$aix_default_options = apply_filters('aix_default_aix_options', $aix_default_options);
	$aix_options = array_merge($aix_default_options, $aix_options);

	return $aix_options;
}

function the_aix_image($attachment_id, $size, $crop = true, $imgix_options = []) {
	echo get_aix_image($attachment_id, $size, $crop, $imgix_options);
}

function get_aix_file_url($attachment_id) {
	if (!$attachment_id) return;

	$file_url = wp_get_attachment_url($attachment_id);
	if (!$file_url || gettype($file_url) != 'string') return false;

	$use_content_url_for_replacement =  get_option('appex_imgix-use-content-url-for-replacement');
	$replacement = null;

	if ($use_content_url_for_replacement == 'on') {
		$replacement = WP_CONTENT_URL;
	} elseif (defined('S3_UPLOADS_BUCKET')) {
		$bucket = strtok(S3_UPLOADS_BUCKET, '/');
		$replacement = 'https://'. $bucket .'.s3.amazonaws.com';
	}

	$file_url = explode($replacement .'/uploads/', $file_url)[1];

	return $file_url;
}

function get_aix_imgix_raw_url($attachment_id) {
	if (!$attachment_id) return;

	$file_url = get_aix_file_url($attachment_id);
	$imgix_url = get_option('appex_imgix-domain');
	$builder = new UrlBuilder($imgix_url);
	$builder->setUseHttps(true);

	if (get_option('appex_imgix-secure-urls') == 'on') {
		$builder->setSignKey(get_option('appex_imgix-secure-urls-token'));
	}

	$img_src = $builder->createURL($file_url);

	return $img_src;
}

/**
 * get_aix_image_src_by_url()
 * This function returns an image url from the Imgix Proxy
 *
 * @since 1.0.0
 *
 * @param int $image_url
 * @param array $size
 * @param boolean $crop
 * @param array $imgix_options
 * @return string
 */
function get_aix_image_src_by_url($image_url, $size, $crop = true, $imgix_options = []) {
	if (!$image_url) return;

	if (is_array(($size))) {
		if (isset($size[0])) {
			$imgix_options['w'] = $size[0];
		}

		if (isset($size[1])) {
			$imgix_options['h'] = $size[1];
		}
	}

	if ($crop) {
		$imgix_options['fit'] = 'crop';
	}

	$imgix_options = appex_imgix_set_imgix_options($imgix_options);

	$file_url = $image_url;

	$imgix_url = get_option('appex_imgix-domain');
	$builder = new UrlBuilder($imgix_url);
	$builder->setUseHttps(true);

	if (get_option('appex_imgix-secure-urls') == 'on') {
		$builder->setSignKey(get_option('appex_imgix-secure-urls-token'));
	}

	$img_src = $builder->createURL($file_url, $imgix_options);
	$img_hash = hash('md5', $img_src);

	return $img_src;
}

/**
 * get_aix_image_src()
 * This function returns an image url from the Imgix Proxy
 *
 * @since 1.0.0
 *
 * @param int $attachment_id
 * @param array $size
 * @param boolean $crop
 * @param array $imgix_options
 * @return string
 */
function get_aix_image_src($attachment_id, $size, $crop = true, $imgix_options = []) {
	if (!$attachment_id) return;

	if (is_array(($size))) {
		if (isset($size[0])) {
			$imgix_options['w'] = $size[0];
		}

		if (isset($size[1])) {
			$imgix_options['h'] = $size[1];
		}
	}

	if ($crop) {
		$imgix_options['fit'] = 'crop';
	}

	$imgix_options = appex_imgix_set_imgix_options($imgix_options);
	$file_url = get_aix_file_url($attachment_id);
	$imgix_url = get_option('appex_imgix-domain');
	$builder = new UrlBuilder($imgix_url);
	$builder->setUseHttps(true);

	if (get_option('appex_imgix-secure-urls') == 'on') {
		$builder->setSignKey(get_option('appex_imgix-secure-urls-token'));
	}

	$img_src = $builder->createURL($file_url, $imgix_options);
	$img_hash = hash('md5', $img_src);

	if (get_option('appex_imgix-caching') == 'on') {
		$path = appex_imgix_ensure_cache_folder_exists();
		$image_meta = wp_prepare_attachment_for_js($attachment_id);

		$extension_pos = strrpos($image_meta['filename'], '.'); // Find position of the last dot, so where the extension starts
		$name = substr($image_meta['filename'], 0, $extension_pos) .'__'. $img_hash . substr($image_meta['filename'], $extension_pos);

		// Force changing file extension if fm=jpg (all files converted to .jpg by Imgix)
		if (isset($imgix_options['fm']) && $imgix_options['fm'] == 'jpg') {
			$name = str_replace('.png', '.jpg', $name);
			$name = str_replace('.gif', '.jpg', $name);
			$name = str_replace('.bmp', '.jpg', $name);
		}

		if (false == ($image_local_src = appex_imgix_cached_image_exists($name, $attachment_id))) {
			$file = file_get_contents($img_src);
			$bytes_written = file_put_contents($path . $name, $file);

			// Once in a blue moon the files are saved but with zero bytes written. Delete these, so that we dont store corrupt files
			if ($bytes_written == 0) {
				unlink($path.$name);
			}

			//update_post_meta($attachment_id, 'aix_image_'. $img_hash, $name);
		}

		if ($image_local_src) {
			$img_src = $image_local_src;
		}
	}

	return $img_src;
}

/**
 * get_aix_image()
 * This function returns an image tag via the Imgix Proxy
 *
 * @param int $attachment_id
 * @param array $size
 * @param boolean $crop
 * @param array $imgix_options
 * @param array $aix_options
 * @return string
 */
function get_aix_image($attachment_id, $size, $crop = true, $imgix_options = [], $aix_options = []) {
	if (!$attachment_id) return;

	$imgix_options = appex_imgix_set_imgix_options($imgix_options);
	$aix_options = appex_imgix_set_aix_options($aix_options);
	$image_meta = appex_imgix_get_image_meta($attachment_id);
	$img_src = get_aix_image_src($attachment_id, $size, $crop, $imgix_options);
	$img_title = false;
	$img_caption = false;

	// Prepare image meta data
	if (isset($image_meta['title']) && $image_meta['title'] && $aix_options['output_title']) {
		$img_title = ' title="' . esc_attr($image_meta['title']) . '"';
	}

	if (isset($image_meta['alt']) && $image_meta['alt']) {
		$img_alt = ' alt="' . esc_attr($image_meta['alt']) . '"';
	} else {
		$img_alt = ' alt=""';
	}

	$src = 'src';
	$src_default = null;
	$width_height_attrs = null;
	$class = null;

	$image_array = [
		'width' => 0,
		'height' => 0,
	];

	if (!empty($aix_options['return_data_src'])) {
		$src = 'data-src';
		$src_default = ' src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="';
	}

	if (!empty($aix_options['flickity_lazyload'])) {
		$src = 'data-flickity-lazyload-src';
		$src_default = ' src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="';
	}

	if (!empty($aix_options['img_class'])) {
		$class = ' class="' . $aix_options['img_class'] . '" ';
	}

	if (is_array($size)) {
		if (isset($size[0])) {
			$image_array['width'] = $size[0];
		}

		if (isset($size[1])) {
			$image_array['height'] = $size[1];
		} else {
			if (isset($image_meta['height']) && isset($image_meta['width'])) {
				$proportion = $image_meta['height'] / $image_meta['width'];
				$image_array['height'] = (int) round($size[0] * $proportion);
			}
		}
	}

	if (!empty($aix_options['return_width_and_height_attrs']) && is_numeric($image_array['width'])) {
		$width_height_attrs = 'width="' . $image_array['width'] . '" height="' . $image_array['height'] . '"' ;
	}

	if (is_int($image_array['height']) && $image_array['height'] > 0 && is_int($image_array['width']) && $image_array['width'] > 0) {
		$image_array['h_proportion'] =  $image_array['height'] / $image_array['width'] ;
		$image_array['h_percentage'] = round((float) $image_array['h_proportion'] * 100 , 4) .'%';
	} else {
		$image_array['h_percentage'] = 0;
	}

	// Generate picture markup
	$image = '<img '. $width_height_attrs . $src_default . $class .' '. $src .'="'. $img_src .'" '. $img_title . $img_alt .'>';

	if ($aix_options['insert_placeholder']) {
		$image_pl = '<div class="img-pl" style="padding-bottom: '. $image_array['h_percentage'] .'; height: 0;">';
		$image_pl .= $image;
		$image_pl .= '</div>';
		$image = $image_pl;
	}

	if ($aix_options['show_caption']) {
		$markup = '<figure>';
		$markup .= $image;
		$markup .= '<figcaption>';

		if ($aix_options['caption_prefix']) {
			$markup .= '<span class="caption__prefix">'. $aix_options['caption_prefix'] .'</span>';
		}

		if (!empty($image_meta['caption'])) {
			$markup .= $image_meta['caption'];
		}

		if ($aix_options['caption_suffix']) {
			$markup .= '<span class="caption__suffix">'. $aix_options['caption_suffix'] .'</span>';
		}

		$markup .= '</figcaption>';
		$markup .= '</figure>';

		$image = $markup;
	}

	return $image;
}

function the_aix_picture($attachment_id, $image_sizes, $crop = true, $imgix_options = [], $aix_options = []) {
	echo get_aix_picture_set($attachment_id, $image_sizes, $crop, $imgix_options, $aix_options);
}

function get_aix_picture_set($attachment_id, $image_sizes, $crop = true, $imgix_options = [], $aix_options = []) {
	if (!$attachment_id) return;

	$imgix_options = appex_imgix_set_imgix_options($imgix_options);
	$aix_options = appex_imgix_set_aix_options($aix_options);
	$aix_options['insert_placeholder'] = false; // We cannot use placeholders in this context
	$image = '<picture>';
	$keys = array_keys($image_sizes);
	$image_sizes_last_key = $keys[count($keys)-1];

	if ($crop) {
		$imgix_options['fit'] = 'crop';
	}

	foreach ($image_sizes as $key => $srcset_options) {
		if (!empty($aix_options['return_data_src'])) {
			$srcset_options['return_data_src'] = 1;
		}

		$image .= appex_imgix_get_srcset($attachment_id, $srcset_options, $crop, $imgix_options);
	}

	// Use the largest of the provided image sizes as fallback image
	$imgix_params_fallback_image_size = [$image_sizes[$image_sizes_last_key]['size'][0], $image_sizes[$image_sizes_last_key]['size'][1]];
	$image .= "\n". get_aix_image($attachment_id, $imgix_params_fallback_image_size, $crop, $imgix_options, $aix_options) ."\n";
	$image .= '</picture>';

	return $image;
}

function appex_imgix_get_srcset($attachment_id, $srcset_options, $crop, $imgix_options = []) {
	$src = 'srcset';
	$src_default = '';

	if (isset($srcset_options['return_data_src']) && $srcset_options['return_data_src'] == 1) {
		$src = 'data-srcset';
		$src_default = ' srcset="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="';
	}

	$markup = '<source' .$src_default.' media="'. $srcset_options['mq'] .'" sizes="(max-width: '. round($srcset_options['size'][0]) .'px) 100vw, '. round($srcset_options['size'][0]) .'px" '.$src.'="';
	$markup .= get_aix_image_src($attachment_id, $srcset_options['size'], $crop, $imgix_options).' '. $srcset_options['size'][0] .'w';
	$markup .= '">';

	return $markup;
}

function appex_imgix_get_image_meta($attachment_id) {
	$image_meta = wp_prepare_attachment_for_js($attachment_id);
	$title = $caption = $alt = $width = $height = false;
	$image_fields = ['title', 'caption', 'alt', 'width', 'height', 'description'];

	// Setup variables if meta data exists
	foreach ($image_fields as $image_field) {
		if (isset($image_meta[$image_field]) && $image_meta[$image_field]) {
			$$image_field = $image_meta[$image_field];
		}
	}

	$source_for_alt = [
		'alt',
		'description',
		'caption',
		'title'
	];

	foreach ($source_for_alt as $key => $source) {
		if (!empty($$source)) {
			$alt = $$source;
			break;
		}
	}

	return [
		'title' => $title,
		'alt' => esc_attr($alt),
		'caption' => $caption,
		'width' => $width,
		'height' => $height
	];
}

function aix_image_get_aspect_ratio($attachment_id, $image_portrait_min_ratio = 1) {
	$image_meta = appex_imgix_get_image_meta($attachment_id);
	if (!$image_meta['width'] || !$image_meta['height']) {
		return 'landscape';
	}
	$image_ratio = $image_meta['width'] / $image_meta['height'];

	if ($image_ratio < $image_portrait_min_ratio) {
		return 'portrait';
	} else {
		return 'landscape';
	}
}

function aix_get_all_image_sizes() {
	global $_wp_additional_image_sizes;
	$default_image_sizes = get_intermediate_image_sizes();

	foreach ($default_image_sizes as $size) {
		$image_sizes[$size]['width'] = intval(get_option("{$size}_size_w"));
		$image_sizes[$size]['height'] = intval(get_option("{$size}_size_h"));
		$image_sizes[$size]['crop'] = get_option("{$size}_crop") ? get_option("{$size}_crop") : false;
	}

	if (isset($_wp_additional_image_sizes) && count($_wp_additional_image_sizes)) {
		$image_sizes = array_merge($image_sizes, $_wp_additional_image_sizes);
	}

	return $image_sizes;
}

function aix_get_attribute($element, $attribute) {
	preg_match('/'. $attribute .'="([^"]*)"/', $element, $result);

	if ($result && $result[1]) {
		return $result[1];
	} else {
		return false;
	}
}

function aix_blocks($block_content, $block) {
	$imgix_blocks = [
		'core/image',
		'core/cover',
		'core/media-text',
	];

	if (in_array($block['blockName'], $imgix_blocks)) {
		if ($block['attrs']['id'] || $block['attrs']['mediaId']) {
			if ($block['attrs']['id']) {
				$attachment_id = $block['attrs']['id'];
			} else if ($block['attrs']['mediaId']) {
				$attachment_id = $block['attrs']['mediaId'];
			} else {
				return $block_content;
			}

			// Check if attachment exists
			$attachment_exists = get_post_status($attachment_id);
			if (!$attachment_exists) {
				return $block_content;
			}

			// Not run on SVGs or GIFs
			$attachment_mime_type = get_post_mime_type($attachment_id);
			if ($attachment_mime_type == 'image/svg+xml' || $attachment_mime_type == 'image/gif') {
				return $block_content;
			}

			$width = $block['attrs']['width'];
			$height = $block['attrs']['height'];
			$size_slug = $block['attrs']['sizeSlug'];

			// Get original image tag
			preg_match('/<img(.*?)>/s', $block_content, $original_image);

			$original_class = aix_get_attribute($original_image[0], 'class');
			$original_style = aix_get_attribute($original_image[0], 'style');

			// Manually defined size in editor
			if ($width && $height) {
				$imgix_image = get_aix_image($attachment_id, [$width, $height], true, [], ['img_class' => $original_class]);
				$imgix_url = get_aix_image_src($attachment_id, [$width, $height], true);

			} else {
				// Use WordPress image sizes
				if (!$size_slug) {
					$size_slug = 'full';
				}

				$all_image_sizes = aix_get_all_image_sizes();
				$width = $all_image_sizes[$size_slug]['width'];
				$max_width = get_option('appex_imgix-max-width') ? get_option('appex_imgix-max-width') : 1500;

				if (!is_int($width)) {
					$width = $max_width;
				}

				$meta = wp_get_attachment_metadata($attachment_id);
				$image_sizes = [];

				// Sort sizes array from smallest to largest
				if (!empty($meta['sizes'])) {
					usort($meta['sizes'], function ($item1, $item2) {
						return $item1['width'] <=> $item2['width'];
					});

					$has_max_width_in_sizes = false;

					foreach ($meta['sizes'] as $size) {
						if ($size['width'] <= $width) {
							$image_sizes[] = [
								'size' => [$size['width'], $size['height']],
								'mq' => '(max-width: ' . $size['width'] . 'px)',
							];
						}

						if ($size['width'] == $max_width) {
							$has_max_width_in_sizes = true;
						}
					}
				}

				if ($meta['width'] === $max_width && !$has_max_width_in_sizes) {
					$image_sizes[] = [
						'size' => [$meta['width'], $meta['height']],
						'mq' => '(max-width: ' . $meta['width'] . 'px)',
					];
				}

				// Get Imgix picture
				$imgix_image = get_aix_picture_set($attachment_id, $image_sizes, true, [], ['img_class' => $original_class]);

				// Get Imgix URL (for media-text)
				$imgix_url = get_aix_image_src($attachment_id, [$width, 0], true);
			}

			// add width and height attributes to image tag in imgix_image
			$imgix_image = preg_replace('/<img(.*?)>/', '<img$1 width="' . $width . '" height="' . $height . '">', $imgix_image);

			// Add original styles to new image tag
			// Cover block uses styles to set focus point
			if ($original_style) {
				$imgix_image = preg_replace('/(<img\b[^><]*)>/i', '$1 style="'. $original_style .'">', $imgix_image);
			}

			// Replace original image tag with Imgix picture
			$block_content = str_replace($original_image[0], $imgix_image, $block_content);

			// If is media-text, replace background-image with Imgix URL
			if ($block['blockName'] == 'core/media-text') {
				$block_content = preg_replace('/background-image:url\((.*?)\)/', 'background-image:url('. $imgix_url .')', $block_content);
			}
		}
	}
	return $block_content;
}

function aix_core_wp_calculate_image_srcset($size_array, $image_src, $image_meta, $attachment_id = 0) {
	// srcset is already placed in <source> tags, so having it in the <img> tag is redundant
	return false;
}

if (!is_admin() && get_option('appex_imgix-use-core-blocks') == 'on') {
	add_filter('wp_calculate_image_srcset', 'aix_core_wp_calculate_image_srcset', 10, 3);
	add_filter('render_block', 'aix_blocks', 10, 2);
}

function aix_core_wp_get_attachment_image_src($image, $attachment_id, $size) {
	$attachment_mime_type = get_post_mime_type($attachment_id);

	if ($attachment_mime_type == 'image/svg+xml' || $attachment_mime_type == 'image/gif') {
		return $image;
	}

	$crop = false;
	$max_width = get_option('appex_imgix-max-width') ? get_option('appex_imgix-max-width') : 1500;

	if (is_array($size)) {
		$width = $size[0];
		$height = $size[1];
		$crop = true;
	} elseif ($size == 'full' || $size == 'original' || !$size) {
		$width = $image[1];
		$height = $image[2];

		if ($width > $max_width) {
			$width = $max_width;
			$height = 0;
		}
	} elseif ($size) {
		$all_image_sizes = aix_get_all_image_sizes();

		if (isset($all_image_sizes[$size])) {
			$width = $all_image_sizes[$size]['width'];
			$height = $all_image_sizes[$size]['height'];
			$crop = $all_image_sizes[$size]['crop'];
		}
	}

	if ($height == 9999) {
		$height = 0;
	}

	$size = [$width, $height];
	$image_url = get_aix_image_src($attachment_id, $size, $crop);

	return [$image_url, $width, $height];
}

function aix_core_content_images($content) {
	preg_match_all('/<img[^>]+>/i', $content, $images);

	if ($images && $images[0]) {
		foreach ($images[0] as $image) {
			preg_match('/wp-image-([0-9]+)/i', $image, $attachment_id);

			if (!empty($attachment_id)) {
				$attachment_id = $attachment_id[1];
			} else {
				continue;
			}

			$attachment_mime_type = get_post_mime_type($attachment_id);

			if ($attachment_mime_type == 'image/svg+xml' || $attachment_mime_type == 'image/gif') {
				continue;
			}

			$width = aix_get_attribute($image, 'width');

			if (!$width) {
				continue;
			}

			$height = aix_get_attribute($image, 'height');
			$original_class = aix_get_attribute($image, 'class');

			$imgix_image = get_aix_image($attachment_id, [$width, $height], true, [], ['img_class' => $original_class]);
			$content = str_replace($image, $imgix_image, $content);
		}
	}
	return $content;
}

if (!is_admin() && get_option('appex_imgix-replace-core-functions') == 'on') {
	add_filter('wp_get_attachment_image_src', 'aix_core_wp_get_attachment_image_src', 10, 3);
}

if (get_option('appex_imgix-replace-post-content') == 'on') {
	add_filter('the_content', 'aix_core_content_images', 10, 1);
}
