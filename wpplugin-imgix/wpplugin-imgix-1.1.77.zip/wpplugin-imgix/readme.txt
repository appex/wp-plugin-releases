== Changelog ==
= 1.1.77 =
security: Remove embedded GitHub token. Updates are now served from the public appex/wp-plugin-releases repo and need no credentials.
= 1.1.76 =
fix: define properties for the crop method class
= 1.1.75 =
fix(get_aix_image): output empty alt tag if image is missing alt text
= 1.1.74 =
Fix: Remove translations that are being triggered too early.
= 1.1.73 =
Fix division by zero bug for aspect ratio calculation.
= 1.1.72 =
Add support for core/media-text block.
= 1.1.71 =
Check if `$file_url` is a string in `get_aix_file_url`.
= 1.1.70 =
Implode `$field['value']` to avoid "Array to string conversion" PHP warnings.
= 1.1.69 =
Check if `$size` is an array in `get_aix_image` before trying to override `$image_array` values. Replace all arrays with short array syntax.
= 1.1.68 =
Version fix
= 1.1.67 =
Added null check for imgix_options array
= 1.1.66 =
Defined $includeLibraryParam in UrlBuilder as Dynamic Properties are deprecated
= 1.1.65 =
Bugfix for render_field, removed unused code
= 1.1.64 =
Bugfix for division by zero if image metadata has no height
= 1.1.63 =
Update Plugin Update Checker to version 5
= 1.1.62 =
Minor bugfix on unhandled 0 division
= 1.1.61 =
Not pass .gif files through Imgix on blocks and core functions
= 1.1.60 =
Added option to set max width
= 1.1.59 =
Only crop image sizes if it's set to crop.
= 1.1.58 =
Bug fixes for Gutenberg blocks.
= 1.1.57 =
Add support for core Gutenberg blocks, core WordPress functions, and TinyMCE content.
= 1.1.56 =
Fix console error for undefined acf on wp plugin page
= 1.1.55 =
Support crop method and focal point selection in media modal
= 1.1.54 =
Support crop method and focal point selection on attachment page
= 1.1.53 =
Added ability to feed in external URL
= 1.1.52 =
Updated plugin update checker class to version 4.9
= 1.1.51 =
Height/width attribute support
= 1.1.50 =
Removed unnedded flickity lazyload code for srcset, as this was causing PHP notices
= 1.1.49 =
Added support for lazyloading images in Flickity by setting flickity_lazyload=true (remember to add the lazyload parameter to your JS as well)
= 1.1.48 =
Updated Plugin Updater Class to latest version
= 1.1.45 =
appex_imgix_get_image_meta now returns alt and title as raw text instead of HTML tags
= 1.1.44 =
Captions will now show without captions-text as long as either a suffix og prefix is provided.
= 1.1.43 =
Added function to get the raw URL of image via Imigx. For use in Vue sites. Also separated out function to get $file_url variable.
= 1.1.42 =
Added support for images hosted on Amazon S3
= 1.1.41 =
Added format value to auto parameter to further optimize images in supported browser
= 1.1.40 =
Added function for checking if a image is portrait or landscape
= 1.1.39 =
Content url constant as option
= 1.1.38 =
Use constant to derive url to allow better flexibility with multi-tenancy setup
= 1.1.37 =
Removed two unused functions which should increase performance
= 1.1.36 =
Added crop method field, and drag and drop for focal point
= 1.1.35 =
Added caption suffix option
= 1.1.34 =
Fix PHP notice
= 1.1.33 =
Change filenames in cache if fm=jpg
= 1.1.31 =
Fix class missing quote
= 1.1.30 =
Set up cascading source for alt attribute on <img>. Alt -> Description -> Caption -> Title
= 1.1.29 =
Move cache folder into uploads. Only output title if explicitly required with argument.
= 1.1.28 =
Add missing composer.json
= 1.1.27 =
Fix minor issue
= 1.1.26 =
Simplified markup for <picture> source set, which also passes W3C validation
= 1.1.25 =
Dont use Composer to fetch Imgix SDK, store in repo instead. Was causing problems on some local environments.
= 1.1.24 =
Added caption prefix option
= 1.1.23 =
Use Imgix client library to generate URLS + added support for Secure Urls
= 1.1.22 =
Fix cache problem when storing filenames with foreign characters
= 1.1.21 =
Ensure correct imgix_options when using aix_picture_set
= 1.1.20 =
Cleanup and bugfixing for get_aix_picture_set()
= 1.1.19 =
Added 1px gif when using lazyloading
= 1.1.18 =
Fixed hashing method
= 1.1.17 =
Added option to enable local cache (experimental)
= 1.1.16 =
Added filter to replace parts of urls
= 1.1.14 =
Added readme.txt
