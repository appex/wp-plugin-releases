/* eslint-disable no-undef */
function activateCropSelects() {
    // DOM variables
    const cropSelects = document.querySelectorAll('.appex_imgix_crop_method_select');

    // Event listeners
    if (cropSelects.length > 0) {
        window.dragstart = function (ev) {
            // Add the drag data
            const elem = ev.target;
            elem.className += ' held';
            setTimeout(() => (elem.className = 'invisible'), 0);
        };

        window.dragend = function (ev) {
            const elem = ev.target;
            elem.imageDiv = elem.parentNode;
            elem.containerPos = elem.imageDiv.getBoundingClientRect();

            elem.fieldGroup = elem.parentNode.parentNode.parentNode.parentNode.parentNode;
            elem.valueField = elem.fieldGroup.querySelector('.appex_imgix_crop_method');
            elem.dotPosHorizontal = elem.valueField.nextSibling;
            elem.dotPosVertical = elem.dotPosHorizontal.nextSibling;

            let offsetX = ev.x - elem.containerPos.x;
            let offsetY = ev.y - elem.containerPos.y;

            if (offsetX < 0) {
                offsetX = 0;
            }

            if (offsetX > elem.containerPos.width) {
                offsetX = elem.containerPos.width;
            }

            if (offsetY < 0) {
                offsetY = 0;
            }

            if (offsetY > elem.containerPos.height) {
                offsetY = elem.containerPos.height;
            }

            const xPercent = Math.floor((offsetX / elem.containerPos.width) * 100);
            const yPercent = Math.floor((offsetY / elem.containerPos.height) * 100);

            elem.dotPosHorizontal.value = xPercent;
            elem.dotPosVertical.value = yPercent;
            elem.className = 'focal-dot';
            elem.style.left = `${xPercent}%`;
            elem.style.top = `${yPercent}%`;
            elem.valueField.value = `focalpoint;${xPercent};${yPercent}`;

            const imageDiv = elem.parentNode.parentNode.querySelector('.image-wrap');
            if (imageDiv) {
                const connectedSelect = imageDiv.cropSelectRef;
                if (connectedSelect) {
                    connectedSelect.dispatchEvent(new window.Event('change', { bubbles: true }));
                }
            }
        };

        cropSelects.forEach((cropSelect, i) => {
            cropSelect.imageDiv =
                cropSelect.parentNode.parentNode.parentNode.querySelector('.acf-field-image .image-wrap');

            if (cropSelect.imageDiv) {
                cropSelect.imageDiv.classList.add('appex_imgix_crop_image_wrapper');
                cropSelect.cropSelectRef = cropSelect;
            } else {
                // We are on an attachment page (?) or media dialog

                const attachmentPageImageWrapper = document.querySelector('.media-frame-content .details-image');
                const postAttachmentDialogImageWrapper = document.querySelector(
                    '.media-frame-content .attachment-details .attachment-info .thumbnail'
                );

                const el = attachmentPageImageWrapper || postAttachmentDialogImageWrapper;

                if (el) {
                    el.cropSelectRef = cropSelect;

                    if (attachmentPageImageWrapper) {
                        const wrapper = document.createElement('div');
                        wrapper.className = 'image-wrap';
                        wrapper.style.margin = 'auto';
                        wrapper.style.width = 'fit-content';
                        wrapper.style.position = 'relative';
                        el.parentNode.insertBefore(wrapper, el);
                        wrapper.appendChild(el);
                    } else {
                        postAttachmentDialogImageWrapper.classList.add('image-wrap');
                    }

                    cropSelect.imageDiv = document.querySelector('.media-frame-content .image-wrap');
                    cropSelect.imageDiv.cropSelectRef = cropSelect;
                }
            }

            cropSelect.valueField = cropSelect.nextSibling;
            cropSelect.dotPosHorizontal = cropSelect.valueField.nextSibling;
            cropSelect.dotPosVertical = cropSelect.dotPosHorizontal.nextSibling;

            cropSelect.addEventListener('input', (event) => {
                checkCropMethod(cropSelect);
            });

            checkCropMethod(cropSelect);

            cropSelect.dotPosHorizontal.addEventListener('input', (event) => {
                setDotPosHorizontal(event.target.value, cropSelect);
            });

            cropSelect.dotPosVertical.addEventListener('input', (event) => {
                setDotPosVertical(event.target.value, cropSelect);
            });

            cropSelect.dot = cropSelect.imageDiv.querySelector('.focal-dot');

            if (cropSelect.dot) {
            }
        });
    }

    // Focal dot functions
    function addDotIfMissing(elem) {
        const dot = elem.imageDiv.querySelector('.focal-dot');

        if (!dot) {
            elem.imageDiv.insertAdjacentHTML(
                'beforeend',
                '<div draggable="true" ondragstart="dragstart(event);" ondragend="dragend(event);" class="focal-dot"></div>'
            );
        }
    }

    function removeDotIfExists(elem) {
        const dot = elem.imageDiv.querySelector('.focal-dot');

        if (dot) {
            elem.imageDiv.removeChild(dot);
        }
    }

    function checkCropMethod(elem) {
        // 'acf-field-5c7697253f7e8'
        if (elem.value === 'focalpoint') {
            addDotIfMissing(elem);
            setDotPosHorizontal(elem.dotPosHorizontal.value, elem);
            setDotPosVertical(elem.dotPosVertical.value, elem);

            elem.valueField.value = `focalpoint;${elem.dotPosHorizontal.value};${elem.dotPosVertical.value}`;
        } else {
            elem.valueField.value = elem.value;
            removeDotIfExists(elem);
        }
    }

    function setDotPosHorizontal(value, elem) {
        const dot = elem.imageDiv.querySelector('.focal-dot');
        dot.style.left = `${value}%`;
    }

    function setDotPosVertical(value, elem) {
        const dot = elem.imageDiv.querySelector('.focal-dot');
        dot.style.top = `${value}%`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const cropSelects = document.querySelectorAll('.appex_imgix_crop_method_select');
    if (cropSelects.length > 0) {
        activateCropSelects();
    } else if (window.acf !== undefined) {
        window.acf.addAction('new_field/type=crop_method', () => {
            activateCropSelects();
        });
    }
});
