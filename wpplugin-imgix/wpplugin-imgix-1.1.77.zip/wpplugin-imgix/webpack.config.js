// webpack v4
const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const LiveReloadPlugin = require('webpack-livereload-plugin');

module.exports = {
    entry: {
        main: './src/appex-imgix-admin-script.js',
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'appex-imgix-admin-script.js',
    },
    optimization: {
        namedModules: true,
    },
    watch: true,
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                },
            },
            {
                test: /\.s?css$/,
                use: [MiniCssExtractPlugin.loader, 'css-loader', 'sass-loader'],
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use: ['file-loader'],
            },
        ],
    },
    plugins: [
        new MiniCssExtractPlugin({
            filename: 'appex-imgix-admin-style.css',
            chunkFilename: 'appex-imgix-admin-style.css',
        }),
        new LiveReloadPlugin(),
    ],
};
